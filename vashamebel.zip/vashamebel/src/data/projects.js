export const projectTypes = [
  {
    slug: "kitchens",
    title: "Кухни",
    imageSrc: "/images/kitchen/kitchen-1.png",
  },
  {
    slug: "wardrobes",
    title: "Шкафы",
    imageSrc: "/images/wardrobes/wardrobes-1.jpg",
  },
  {
    slug: "living-rooms",
    title: "Мебель для гостиной",
    imageSrc: "/images/living-rooms/living-room.jpg",
  },
  {
    slug: "dressers",
    title: "Комоды",
    imageSrc: "/images/dressers/dresser.jpg",
  },
  {
    slug: "hallways",
    title: "Прихожие",
    imageSrc: "/images/hallways/hallway.jpg",
  },
];


// Расширенные данные о конкретных выполненных проектах
export const projectsData = [
  // --- КУХНИ ---
  { 
    id: 1, 
    type: "kitchens",
    slug: "loft-kitchen-3", 
    name: "Кухня в стиле Лофт", 
    mainImage: "/images/kitchen/kitchen-1.png",
    images: [
        "/images/kitchen/kitchen-1.png",
        
    ],
    description: "Современная и практичная кухня в стиле лофт. Сочетание текстуры дерева и металла создает уютную и в то же время индустриальную атмосферу. Продумана до мелочей для вашего удобства.",
    characteristics: [
      { label: "Материал корпуса", value: "ЛДСП Kronospan" },
      { label: "Фасады", value: "Пластик FENIX NTM" },
      { label: "Столешница", value: "Постформинг Egger" },
      { label: "Фурнитура", value: "Blum (Австрия)" },
    ]
  },
  // --- ШКАФЫ ---
  { 
    id: 2, 
    type: "wardrobes",
    slug: "modern-wardrobe-1", 
    name: "Шкаф-купе 'Модерн'", 
    mainImage: "/images/wardrobes/wardrobe-1.jpg",
    images: [
      "/images/wardrobes/wardrobe-1.jpg",
    ],
    description: "Стильный и вместительный шкаф-купе в современном стиле. Идеально подходит для спален и прихожих, обеспечивая максимальную функциональность при минималистичном дизайне. Двери с плавным ходом и качественная фурнитура гарантируют долгий срок службы.",
    characteristics: [
      { label: "Материал корпуса", value: "ЛДСП Egger (Австрия)" },
      { label: "Фасады", value: "Зеркало с пескоструйным рисунком" },
      { label: "Профили дверей", value: "Алюминиевый профиль Senator" },
      { label: "Срок изготовления", value: "14-21 день" },
    ]
  },
  { 
    id: 3, 
    type: "wardrobes",
    slug: "classic-wardrobe-2", 
    name: "Встроенный шкаф 'Классика'", 
    mainImage: "/images/wardrobes/wardrobe-2.jpg",
    images: ["/images/wardrobes/wardrobe-2.jpg"],
    description: "Элегантный встроенный шкаф, который идеально вписывается в интерьер, создавая ощущение единого пространства. Классический дизайн и премиальные материалы.",
    characteristics: [
      { label: "Материал корпуса", value: "МДФ крашеный" },
      { label: "Фасады", value: "Фрезерованный МДФ с патиной" },
      { label: "Срок изготовления", value: "21-30 дней" },
    ]
  },
  
  
  //--- МЕБЕЛЬ ДЛЯ ГОСТИНОЙ --- 
  { 
    id: 4, 
    type: "hallways",
    slug: "hallways-1", 
    name: "Прихожая 'Элегант'", 
    mainImage: "/images/hallways/a1.jpg",
    images: [
        "/images/hallways/a1.jpg",
        "/images/hallways/a2.jpg",
    ],
    description: "Современная и практичная прихожая в стиле лофт. Сочетание текстуры дерева и металла создает уютную и в то же время индустриальную атмосферу. Продумана до мелочей для вашего удобства.",
    characteristics: [
      { label: "Материал корпуса", value: "ЛДСП Kronospan" },
      { label: "Фасады", value: "Пластик FENIX NTM" },
      { label: "Столешница", value: "Постформинг Egger" },
      { label: "Фурнитура", value: "Blum (Австрия)" },
    ]
  },
];