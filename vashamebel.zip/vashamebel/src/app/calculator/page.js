'use client';

import { useState, useEffect } from 'react';
import { useModal } from '@/context/ModalContext'; // Импортируем хук для модального окна
import FadeIn from '@/components/FadeIn';

// --- Цены и параметры (в реальном проекте их можно вынести в отдельный файл) ---
const PRICING = {
  LDF: 150,  // Цена за кв.м. ЛДСП
  MDF: 250,  // Цена за кв.м. МДФ
  DOOR: 100, // Цена за одну дверь
};

export default function CalculatorPage() {
  const { openModal } = useModal();

  // 1. --- СОСТОЯНИЕ (STATE) ---
  // Храним все параметры калькулятора в одном объекте
  const [config, setConfig] = useState({
    width: 150,
    height: 220,
    depth: 60,
    material: 'LDF',
    doors: 2,
  });

  // Отдельное состояние для итоговой цены
  const [totalPrice, setTotalPrice] = useState(0);

  // 2. --- ЛОГИКА ПЕРЕСЧЕТА ---
  // useEffect будет срабатывать каждый раз, когда меняется `config`
  useEffect(() => {
    const { width, height, depth, material, doors } = config;
    
    // Считаем площадь всех стенок (упрощенно)
    const backArea = (width / 100) * (height / 100);
    const topBottomArea = (width / 100) * (depth / 100) * 2;
    const sideArea = (height / 100) * (depth / 100) * 2;
    const totalArea = backArea + topBottomArea + sideArea;

    const materialPrice = PRICING[material];
    const doorsPrice = doors * PRICING.DOOR;

    const finalPrice = Math.round(totalArea * materialPrice + doorsPrice);
    
    setTotalPrice(finalPrice);
  }, [config]); // Зависимость от `config` - ключ к пересчету

  // 3. --- ОБРАБОТЧИКИ ИЗМЕНЕНИЙ ---
  const handleConfigChange = (e) => {
    const { name, value } = e.target;
    setConfig(prevConfig => ({
      ...prevConfig,
      [name]: name === 'doors' ? parseInt(value) : value,
    }));
  };

  const handleSliderChange = (e) => {
    const { name, value } = e.target;
    setConfig(prevConfig => ({
      ...prevConfig,
      [name]: parseInt(value),
    }));
  };
  
  // 4. --- ФУНКЦИЯ ДЛЯ ОТПРАВКИ В МОДАЛЬНОЕ ОКНО ---
  const handleGetQuote = () => {
    const interestText = `
      Заявка из калькулятора:
      - Ширина: ${config.width} см
      - Высота: ${config.height} см
      - Глубина: ${config.depth} см
      - Материал: ${config.material}
      - Кол-во дверей: ${config.doors}
      ---
      Примерная стоимость: ${totalPrice} руб.
    `;
    openModal(interestText.trim());
  };

  // 5. --- РАЗМЕТКА (JSX) ---
  return (
    <div className="bg-background min-h-screen">
      <div className="container mx-auto px-6 py-20">
        <FadeIn>
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-text">Калькулятор стоимости</h1>
            <p className="text-lg text-text-dark mt-2">Рассчитайте примерную стоимость вашего будущего шкафа</p>
            <div className="mt-4 h-1 w-24 bg-primary mx-auto"></div>
          </div>
        </FadeIn>

        <FadeIn>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Левая колонка - Настройки */}
            <div className="lg:col-span-2 bg-secondary p-8 rounded-lg shadow-lg space-y-6">
              {/* Ширина */}
              <div>
                <label className="block text-text mb-2">Ширина: <span className="text-primary font-bold">{config.width}</span> см</label>
                <input type="range" name="width" min="100" max="300" step="10" value={config.width} onChange={handleSliderChange} className="w-full h-2 bg-background rounded-lg appearance-none cursor-pointer accent-primary" />
              </div>
              {/* Высота */}
              <div>
                <label className="block text-text mb-2">Высота: <span className="text-primary font-bold">{config.height}</span> см</label>
                <input type="range" name="height" min="200" max="270" step="5" value={config.height} onChange={handleSliderChange} className="w-full h-2 bg-background rounded-lg appearance-none cursor-pointer accent-primary" />
              </div>
              {/* Глубина */}
              <div>
                <label className="block text-text mb-2">Глубина: <span className="text-primary font-bold">{config.depth}</span> см</label>
                <input type="range" name="depth" min="40" max="80" step="5" value={config.depth} onChange={handleSliderChange} className="w-full h-2 bg-background rounded-lg appearance-none cursor-pointer accent-primary" />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                {/* Материал */}
                <div>
                  <label className="block text-text mb-2">Материал фасадов</label>
                  <select name="material" value={config.material} onChange={handleConfigChange} className="w-full p-3 rounded-lg bg-background border border-gray-600 text-text">
                    <option value="LDF">ЛДСП</option>
                    <option value="MDF">МДФ</option>
                  </select>
                </div>
                {/* Количество дверей */}
                <div>
                  <label className="block text-text mb-2">Количество дверей</label>
                  <select name="doors" value={config.doors} onChange={handleConfigChange} className="w-full p-3 rounded-lg bg-background border border-gray-600 text-text">
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Правая колонка - Итог */}
            <div className="bg-secondary p-8 rounded-lg shadow-lg flex flex-col justify-center items-center text-center">
              <p className="text-text-dark text-lg">Примерная стоимость</p>
              <p className="text-primary text-5xl font-bold my-4">{totalPrice} <span className="text-3xl">руб.</span></p>
              <p className="text-text-dark text-sm mb-6">Это предварительный расчет. Точная стоимость будет известна после замера и выбора фурнитуры.</p>
              <button onClick={handleGetQuote} className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-3 px-8 rounded-lg transition-colors text-lg">
                Получить точный расчет
              </button>
            </div>
          </div>
        </FadeIn>
      </div>
    </div>
  );
}